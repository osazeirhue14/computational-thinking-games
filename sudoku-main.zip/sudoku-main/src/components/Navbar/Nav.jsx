import React from 'react';
import "./nav.css";

const Nav = () => {
  return (
    <div className="navbar">
        iSudoku
    </div>
  )
}

export default Nav