import { createContext } from "react";

const sudokuContext = createContext();

export default sudokuContext;